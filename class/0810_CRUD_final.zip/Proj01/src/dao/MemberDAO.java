package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import common.JdbcUtil;

public class MemberDAO {
	
	// 멤버 조회 ----- R: read = select
	public ArrayList<String> getMemberList(){
		
		ArrayList<String> list = new ArrayList<>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM member";
		
		conn = JdbcUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				list.add(rs.getString("userid"));
			}	
		} catch (Exception e) {
			System.out.println("멤버 테이블 조회 실패");
		}finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
		return list;
	}
	
	// 멤버 등록 ----- C: create
	public int insertMember(String userId, String userPwd) {
		
		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO member VALUES(?, ?)";
		
		conn = JdbcUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPwd);
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("member테이블 입력 실패");
		}finally {
			JdbcUtil.close(conn, pstmt);
		}
		return cnt;
	}
	
	//비번 수정 ----- U: update
	public int updateMember(String userId, String userPwd) {
		
		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE member SET userPwd=? WHERE userId=?";
		
		conn = JdbcUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userPwd);
			pstmt.setString(2, userId);			
			cnt = pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("멤버 수정 실패");
		}finally {
			JdbcUtil.close(conn, pstmt);
		}
		
		return cnt;
	}
	
	//아이디 삭제 ----- D: delete
	public int deleteMember(String userId) {

		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM member WHERE userId = ?";
		
		conn = JdbcUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);			
			cnt = pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("멤버 삭제 실패");
		}finally {
			JdbcUtil.close(conn, pstmt);
		}
		
		return cnt;
	}
	

}
