CREATE TABLE member(
	userid varchar2(10), 
	userpwd varchar2(10)
);

SELECT * FROM member;

INSERT INTO member VALUES('id', 'pwd');

UPDATE  member
 SET userpwd = '321'
 WHERE userid = '123';

DELETE FROM member WHERE ; 
 
DROP TABLE member;