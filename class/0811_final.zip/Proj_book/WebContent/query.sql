CREATE TABLE bookshop(
	--primary key는 고유한 내용만 입력해야되서 같은내용 작성시 오류남 not null 안넣어도 어차피 값없으면 오류남
	isbn varchar2(15) primary key,
	title varchar2(50) not null,
	author varchar2(20) not null,
	company varchar2(50),
	price number(10)
);

SELECT * FROM bookshop 
SELECT * FROM bookshop ORDER BY isbn;

INSERT INTO bookshop VALUES('88-90-11','오라클 도전','오라클맨','오라클출판사', 30000);
INSERT INTO bookshop VALUES('80-90-11','JAVA 도전','JAVA맨','JAVA출판사', 50000);


DELETE FROM bookshop WHERE isbn = '88-90-11';

