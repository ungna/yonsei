package biz;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDAO;


@WebServlet("/delete")
public class DeleteBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public DeleteBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		
		PrintWriter out = response.getWriter();
		
		BookDAO dao = new BookDAO();
		int cnt = 0;
				//넘어온 data.getIsbn()값이 isbn에 들어감
		String isbn = request.getParameter("isbn");
		
		cnt = dao.deleteBook(isbn);
		
		if(cnt >0) {
			response.sendRedirect("/list");
		}else {
			out.print("<script>history.back()</script>");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
