package biz;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDAO;
import vo.BookVO;


@WebServlet("/list")
public class ListBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListBookServlet() {
        super();

    }

	//servlet을 request에 담아서 response로 보냄
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		
		
		BookDAO dao = new BookDAO();
		ArrayList<BookVO> list = dao.getBookList();
		
		if(list != null) {
					//booklist라는 변수에 속성(Attribute)을 set함
			request.setAttribute("booklist", list);
		}
									//여기로 감
		request.getRequestDispatcher("/bookList.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
		
	}

}
