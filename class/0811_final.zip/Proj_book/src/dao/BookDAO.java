package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import common.JdbcUtil;
import vo.BookVO;

public class BookDAO {
	//기능을 수정할때는 쿼리(sql)이랑 ?부분(pstm.set)부분만 수정하면됨
	
	//  조회 ----- R: read = select
	public ArrayList<BookVO> getBookList(){
		//BookVO에 있는 Object를 가져옴
		
		ArrayList<BookVO> list = new ArrayList<>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM bookshop ORDER BY isbn";
		
		conn = JdbcUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				//list.add(rs.getString("userid"));
				//list의 형태가 object라서 바꿔야됨
				//vo에set해서  rs에 있는 값을get해서 넣음
				BookVO vo = new BookVO();
				vo.setIsbn(rs.getString("isbn"));
				vo.setTitle(rs.getString("title"));
				vo.setAuthor(rs.getString("author"));
				vo.setCompany(rs.getString("company"));
				vo.setPrice(rs.getInt("price"));
				
				//list에 vo를 넣음
				list.add(vo);
			}	
		} catch (Exception e) {
			System.out.println("Bookshop 테이블 조회 실패");
		}finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
		return list;
	}
	
	//  등록 ----- C: create 
	public int insertBook(BookVO vo) {
		
		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO bookshop VALUES(?, ?, ?, ?, ?)";
		
		conn = JdbcUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getIsbn());
			pstmt.setString(2, vo.getTitle());
			pstmt.setString(3, vo.getAuthor());
			pstmt.setString(4, vo.getCompany());
			pstmt.setInt(5, vo.getPrice());
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Bookshop테이블 입력 실패");
		}finally {
			JdbcUtil.close(conn, pstmt);
		}
		return cnt;
	}
	
	
	//수정 전에 before데이터 불러와서 보여주기용
	public BookVO getBookData (String isbn) {
		
		BookVO vo = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM bookshop WHERE isbn=?";
		
		conn = JdbcUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  isbn);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				vo = new BookVO();
				vo.setIsbn(rs.getString("isbn"));
				vo.setTitle(rs.getString("title"));
				vo.setAuthor(rs.getString("author"));
				vo.setCompany(rs.getString("company"));
				vo.setPrice(rs.getInt("price"));
			}	
		} catch (Exception e) {
			System.out.println("Bookshop 테이블 조회 실패");
		}finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
		return vo;
	}
	
	//수정 ----- U: update   
	public int updateBook(BookVO vo) {
		
		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE bookshop SET title=?, author=?, company=?, price=? WHERE isbn=?";
		
		conn = JdbcUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(5, vo.getIsbn());
			pstmt.setString(1, vo.getTitle());		
			pstmt.setString(2, vo.getAuthor());		
			pstmt.setString(3, vo.getCompany());		
			pstmt.setInt(4, vo.getPrice());			
			cnt = pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("bookshop 수정 실패");
		}finally {
			JdbcUtil.close(conn, pstmt);
		}
		
		return cnt;
	}
	
	//아이디 삭제 ----- D: delete 
	public int deleteBook(String isbn) {

		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM bookshop WHERE isbn = ?";
		
		conn = JdbcUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, isbn);			
			cnt = pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("bookshop 삭제 실패");
		}finally {
			JdbcUtil.close(conn, pstmt);
		}
		
		return cnt;
	}
	

}



