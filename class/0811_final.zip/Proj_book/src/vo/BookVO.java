package vo;

public class BookVO {
	//VO = Value Object
	//query에서 table만든 필드와 일치하는 변수 생성
	private String isbn; 
	private String title;
	private String author;
	private String company;
	private int price;
	
	//생성자 기본
	//우클릭 - source - Generate Constructor using Field
	public BookVO() {
		super();
	}
	
	//생성자(매개변수)
	public BookVO(String isbn, String title, String author, String company, int price) {
		super();
		
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.company = company;
		this.price = price;
		
	}

	//우클릭 - source - Generate Getter Setter
	//private변수에 접근하여 값을 처리하기 위해 Getter Setter사용
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}

	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
}
